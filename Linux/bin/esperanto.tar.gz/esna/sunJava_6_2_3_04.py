import iplanet

class sunJava_6_2_3_04(iplanet.iplanet):
   version = 'Sun Java System Messaging Server 6.2-3.04 (built Jul 15 2005)'
   baseBufLen = 0x2d0
