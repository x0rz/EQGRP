import iplanet

class sunJava_6_2_4_03(iplanet.iplanet):
   version = 'Sun Java System Messaging Server 6.2-4.03 (built Sep 22 2005)'
   baseBufLen = 0x2d8
   bigBufOffset = -0x270c
   socketOffset = -0x3e0
